/**
 * Jobs
 */

'use strict';
var DbUtil = require('../util/DbUtil');
var SNSUtil = require('../util/SNSUtil');
var SNSconnection = new SNSUtil();
var config = require('../../config/config.json');
var sql = require('../../config/sql.json');
var configuration = require('../../config/config.json');
var JobsAPIClient = require('../util/JobsAPIClient');
var HashMap = require('hashmap');
var async = require('async');
var moment = require('moment');
var mysqlDateTimeFormat = 'YYYY-MM-DD HH:mm:ss';
var queryString = require('query-string');
var CommonUtils = require('../util/Common');

function buildData(orgId, rows) {
    var endPoint, querystring, querySearchArray, querySearch, criteriaCounter, valueCounter, endPointURL, value;
    endPoint = '';
    querystring = '?' + 'organization=' + orgId + '&limit=' + configuration.jobsapi.limit + '&limitKey=' + configuration.jobsapi.limitKey;
    querySearch = '';
    for (criteriaCounter = 0; rows !== null && criteriaCounter < rows.length; criteriaCounter++) {
        if (rows[criteriaCounter].criteriaMaster.valueType === 'multi') {
            querySearchArray = rows[criteriaCounter].criteriaLst.value.split(';');
            for (valueCounter = 0; valueCounter < querySearchArray.length; valueCounter++) {
                querySearch = querySearch + '&' + rows[criteriaCounter].criteriaMaster.searchPrefix + querySearchArray[valueCounter];
            }
        } else {
            if (rows[criteriaCounter].criteriaLst.value !== null && rows[criteriaCounter].criteriaLst.value !== '') {
                value = CommonUtils.replaceAll(rows[criteriaCounter].criteriaLst.value, ';', CommonUtils.replaceAll(rows[criteriaCounter].criteriaMaster.delimiter, '\'', ''));
                querySearch = querySearch + '&' + rows[criteriaCounter].criteriaMaster.searchPrefix + value;
            }
        }
    }
    querystring = querystring + querySearch;
    endPointURL = endPoint + querystring;
    endPointURL = endPointURL + configuration.jobsapi.URLSuffix
    return endPointURL;
}

function doBucketingJobsForCampaigns(campaigns, orgId, map, callback) {
    var queryStr, connection, jobsAPI, jobsCount;
    queryStr = sql.jobs.fetchCriteriaByCampaign;
    connection = new DbUtil();
    jobsAPI = new JobsAPIClient();
    connection.fetchSQL(queryStr.replace('%CAMPAIGN_ID%', DbUtil.escape(campaigns[0].campaignLst.campaignId)), function(err, criteria) {
      try {
        if (!err) {
            var queryData, campaignId, campaignHasJobs;
            if (configuration.jobsapi.method === 'GET') {
                queryData = buildData(orgId, criteria);
            } else if (configuration.jobsapi.method === 'POST') {
                queryData = queryString.parse(encodeURI(buildData(orgId, criteria)));
            }

            campaignId = campaigns[0].campaignLst.campaignId;
            campaignHasJobs = false;
            jobsAPI.fetchJobDetails(queryData, function(jobs) {
                console.log('campaignId=' + campaignId + ' Job count Fetched=' + jobs.aggregations.id.buckets.length);
                for (jobsCount = 0; jobs.aggregations.id.buckets !== null && jobsCount < jobs.aggregations.id.buckets.length; jobsCount++) {
                    if (map.has(jobs.aggregations.id.buckets[jobsCount].key)) {
                        map.set(jobs.aggregations.id.buckets[jobsCount].key, campaignId);
                    }
                }
                campaigns.splice(0, 1); // Remove the Campaign that processed for each iteration
                if (campaigns.length > 0) {
                    doBucketingJobsForCampaigns(campaigns, orgId, map, callback);
                } else {
                    callback(null, map);
                }
            });
        } else {
            console.error('something went wrong -' + err);
            throw 'error processing campaign' + campaigns[0].campaignLst.campaignId ;
        }
      }catch(ex){
        console.error('something went wrong -' + ex);  
        campaigns.splice(0, 1); // Remove the Campaign that not processed and continue with next campaign
        if (campaigns.length > 0) {
            doBucketingJobsForCampaigns(campaigns, orgId, map, callback);
        } else {
            callback(null, map);
        }
      }
    });
}

module.exports.getAllJobCount = function(event, context, cb) {

    try {
        var orgId, map, connection, jobsAPI, data, campaignArrUnique, allJobListForOrg = '',
            orgJobCount;
        data = JSON.parse(event.Records[0].Sns.Message);
        if (data.orgId === null || typeof data.orgId === 'undefined') {
            throw 'Missing OrgId';
        }
        console.info('START - Job bucketing triggered by ' + data.operation + ' for organiation id =' + data.orgId);
        orgId = data.orgId;
        map = new HashMap();
        connection = new DbUtil();
        jobsAPI = new JobsAPIClient();
        //connection.createConnection();
        async.auto({
            getAllJobsForOrg: function(callback) {
                var rows, queryData, jobsCount;
                rows = [];
                if (configuration.jobsapi.method === 'GET') {
                    queryData = buildData(orgId, rows);
                } else if (configuration.jobsapi.method === 'POST') {
                    queryData = queryString.parse(buildData(orgId, rows));
                }

                jobsAPI.fetchJobDetails(queryData, function(jobs) {
                    orgJobCount = jobs.aggregations.id.buckets.length;
                    for (jobsCount = 0; jobs.aggregations.id.buckets !== null && jobsCount < jobs.aggregations.id.buckets.length; jobsCount++) {
                        map.set(jobs.aggregations.id.buckets[jobsCount].key, 'Default');
                        allJobListForOrg = (allJobListForOrg === '' ? jobs.aggregations.id.buckets[jobsCount].key : allJobListForOrg + ',' + jobs.aggregations.id.buckets[jobsCount].key);
                    }
                    callback(null, map);
                });
            },
            getAllJobsForOrgByCampaign: ['getAllJobsForOrg', function(result, callback) {
                var queryStr, campaignCounter, defaultCampaignId = 0,
                    defaultCampaignIndexinCampainsArr;
                queryStr = sql.jobs.fetchAllCampaignByOrg;

                connection.fetchSQL(queryStr.replace(/%ORGID%/g, DbUtil.escape(orgId)), function(err, campaigns) {
                    if (!err) {
                        campaignArrUnique = CommonUtils.clone(campaigns);
                        for (campaignCounter = 0; campaignCounter < campaigns.length; campaignCounter++) {
                            if (campaigns[campaignCounter].defaultCampaign.isDefaultCampaign === 'Y') {
                                defaultCampaignIndexinCampainsArr = campaignCounter;
                                defaultCampaignId = campaigns[campaignCounter].campaignLst.campaignId;
                                break;
                            }
                        }

                        if (defaultCampaignId === 0) {
                            var response = {
                                'message': 'No Default Campaign Found!',
                                'success': false
                            };

                            return cb(null, response);
                        }

                        map.forEach(function(value, key) {
                            map.set(key, defaultCampaignId);
                        });
                        campaigns.splice(defaultCampaignIndexinCampainsArr, 1); // Remove the Default Campaign that processed
                        if (campaigns.length === 0) { // only default campaign associated with the organisation
                            callback(null, map);
                        } else {
                            doBucketingJobsForCampaigns(campaigns, orgId, map, callback);
                        }

                    } else {
                        console.error('Something went wrong - ' + err);
                        callback(err, null);
                    }
                });
            }],
            insertOrgCampaignJobCount: ['getAllJobsForOrgByCampaign', function(result, callback) {
                var jobsCountCampaignArr, campaignCount, insertUpdateCampaignValueData, queryInsertUpdateCampaignJobCount,
                    publisherIdArrUnique, publisherCount, insertUpdateOrgValueData, queryInsertUpdateOrgValues;
                // get all publishers
                publisherIdArrUnique = [];
                publisherIdArrUnique = campaignArrUnique[0].publisherLst.publisherIds.split(',');
                //end - get all publishers

                jobsCountCampaignArr = {};
                for (campaignCount = 0; campaignCount < campaignArrUnique.length; campaignCount++) {
                    jobsCountCampaignArr[campaignArrUnique[campaignCount].campaignLst.campaignId] = [];
                }
                map.forEach(function(value, key) {
                    jobsCountCampaignArr[value].push(key);
                });

                insertUpdateOrgValueData = [];
                queryInsertUpdateOrgValues = sql.jobs.insertUpdateOrgValuesSql;

                insertUpdateCampaignValueData = [];
                queryInsertUpdateCampaignJobCount = sql.jobs.insertUpdateCampaignJobCountSql;

                for (publisherCount = 0; publisherCount < publisherIdArrUnique.length; publisherCount++) {

                    insertUpdateOrgValueData.push([
                        orgId,
                        publisherIdArrUnique[publisherCount], // publisher_id_fk
                        1, // value_master_id_fk
                        orgJobCount,
                        'Y',
                        moment(new Date()).format(mysqlDateTimeFormat),
                        moment(new Date()).format(mysqlDateTimeFormat),
                        'system',
                        'system'
                    ]);

                    insertUpdateOrgValueData.push([
                        orgId,
                        publisherIdArrUnique[publisherCount], // publisher_id_fk
                        3, // value_master_id_fk
                        allJobListForOrg,
                        'Y',
                        moment(new Date()).format(mysqlDateTimeFormat),
                        moment(new Date()).format(mysqlDateTimeFormat),
                        'system',
                        'system'
                    ]);

                    for (campaignCount = 0; campaignCount < campaignArrUnique.length; campaignCount++) {
                        // Job Count
                        insertUpdateCampaignValueData.push([
                            campaignArrUnique[campaignCount].campaignLst.campaignId,
                            2, // JOB_COUNT - campaign_value_master,
                            jobsCountCampaignArr[campaignArrUnique[campaignCount].campaignLst.campaignId].length,
                            'Y',
                            'system',
                            'system',
                            moment(new Date()).format(mysqlDateTimeFormat),
                            moment(new Date()).format(mysqlDateTimeFormat),
                            publisherIdArrUnique[publisherCount]
                        ]);
                        // Job list
                        insertUpdateCampaignValueData.push([
                            campaignArrUnique[campaignCount].campaignLst.campaignId,
                            12, // ALL_JOB_LIST - campaign_value_master,
                            jobsCountCampaignArr[campaignArrUnique[campaignCount].campaignLst.campaignId].join(),
                            'Y',
                            'system',
                            'system',
                            moment(new Date()).format(mysqlDateTimeFormat),
                            moment(new Date()).format(mysqlDateTimeFormat),
                            publisherIdArrUnique[publisherCount]
                        ]);

                    }
                }


                connection.executeSQLValues(queryInsertUpdateOrgValues, insertUpdateOrgValueData, function(error, result) {
                    if (error) throw error;
                    console.log('OrgId =' + result.insertId);
                    connection.executeSQLValues(queryInsertUpdateCampaignJobCount, insertUpdateCampaignValueData, function(error, campaignValueId) { // jshint ignore:line
                        if (error) throw error;
                        console.log('Campaign Jobs Bucketing Successful');
                        callback(null, map);
                    });
                });


            }],
            publishJobBucketingEvent: ['getAllJobsForOrg', 'getAllJobsForOrgByCampaign', 'insertOrgCampaignJobCount', function(result, callback) {
                var dataToPublish = {
                    'orgId': orgId,
                    'userId': 'SYSTEM',
                    'operation': data.operation
                };
                SNSconnection.publish(config.SNS.ruleEngineTopic + '-' + config.env.name, orgId + ' Job Bucketing', dataToPublish, context, function(result) {
                    console.log('SNSconnection.publish result=' + result);
                    callback(null, true);
                });
            }]
        }, function(err, result) { /* jshint unused:vars */
            var response;
            //connection.endConnection();
            console.info('END - Job bucketing triggered by ' + data.operation + ' for organiation id =' + data.orgId);
            if (!err) {
                response = {
                    'message': 'Campaign Jobs Bucketing Successful ',
                    'success': true
                };

                return cb(null, response);
            } else {
                console.error('Error while performing Campaign Jobs Bucketing.');
                response = {
                    'message': 'Campaign Jobs Bucketing Unsuccessful - ' + err,
                    'success': false
                };

                return cb(err, response);
            }
        });
    } catch (ex) {
        var response = {
            'message': 'Campaign Jobs Bucketing UnSuccessful :' + ex,
            'success': false
        };

        return cb(ex, response);
    }
};

function scheduledJob(orgIds, context, cb) {
    var orgId, dataToPublish;
    orgId = orgIds[0].orgMaster.orgId;
    dataToPublish = {
        'orgId': orgId,
        'userId': 'SYSTEM',
        'operation': 'getJobCountForAllOrg'
    };
    SNSconnection.publish(config.SNS.jobBuckettingTopic + '-' + config.env.name, orgId + ' Schedule All Org Job Count', dataToPublish, context, function(result) { /* jshint unused:vars */
        orgIds.splice(0, 1); // Remove the Campaign that processed for each iteration
        if (orgIds.length > 0) {
            scheduledJob(orgIds, context, cb);
        } else {
            var response = {
                'message': 'All Org Jobs Bucketing Successful ',
                'success': true
            };
            cb(null, response);
        }
    });
}

module.exports.getJobCountForAllOrg = function(event, context, cb) {
    var queryStr, connection;
    queryStr = sql.jobs.fetchAllOrg;
    connection = new DbUtil();
    connection.fetchSQL(queryStr, function(err, orgIds) {
        if (!err) {
            scheduledJob(orgIds, context, cb);
        } else {
            console.error('Something went wrong - ' + err);
            cb(err, null);
        }
    });

};
